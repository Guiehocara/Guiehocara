/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package areaderetangulo;

import javax.swing.JOptionPane;

/**
 *
 * @author mestr
 */
public class AreadeRetangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int base = Integer.parseInt(JOptionPane.showInputDialog("Qual é a base do retangulo?"));
        int altura = Integer.parseInt(JOptionPane.showInputDialog("qual a altura do retangulo?"));
        int area = base * altura;
        System.out.println("a area do retagulo é"+area);
    }
    
}
