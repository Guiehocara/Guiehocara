/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package areadeumtriangulo;

import javax.swing.JOptionPane;

/**
 *
 * @author mestr
 */
public class Areadeumtriangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int base;
        int altura;
        float area;
        base = Integer.parseInt(JOptionPane.showInputDialog("Qual a base do triangulo?"));
        altura = Integer.parseInt(JOptionPane.showInputDialog("Qual a altura do triangulo?"));
        area = (base * altura) / 2;
        System.out.println("a area do triangulo é: " + area);
    }
    
}
