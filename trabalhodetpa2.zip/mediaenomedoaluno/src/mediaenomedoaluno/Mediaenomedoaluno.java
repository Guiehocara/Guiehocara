/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediaenomedoaluno;

import javax.swing.JOptionPane;

/**
 *
 * @author mestr
 */
public class Mediaenomedoaluno {
    public static void main(String[] args){
        String NomedoAluno;
       NomedoAluno = JOptionPane.showInputDialog("Qual o nome do aluno?");
       float nota1 =  Float.parseFloat(JOptionPane.showInputDialog("Qual é a primeira nota?"));
       int nota2 = Integer.parseInt(JOptionPane.showInputDialog("Qual é a segunda nota?"));
       int nota3 = Integer.parseInt(JOptionPane.showInputDialog("Qual a terceira nota?"));
       int nota4 = Integer.parseInt(JOptionPane.showInputDialog("Qual é a nota 4?"));
       float media = (nota1 + nota2 + nota3 + nota4) / 4;
       System.out.println(NomedoAluno+ " : "+media);
    }
 
    
}
