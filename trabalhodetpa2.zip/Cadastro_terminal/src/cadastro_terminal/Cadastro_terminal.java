/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastro_terminal;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author mestr
 */

public class Cadastro_terminal {
 public static String nome;
         public static String sobreNome;
         public static int idade;
         public static boolean fumante;
         public static int opcao;
         public static double renda;
         public static DecimalFormat df = new DecimalFormat("0.00");
         public static Scanner entrada = new Scanner(System.in);
         
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Iniciando o programa de cadastro");
        System.out.println("Digite o seu primeiro nome:");
        nome = entrada.nextLine();
        System.out.println("Digite seu ultimo nome: ");
        sobreNome = entrada.nextLine();
        System.out.println("Digite a sua idade: ");
        idade = entrada.nextInt();
        System.out.println("Digite 1 para fumante ou 0 para não fumante:");
        opcao = entrada.nextInt();
        if(opcao == 1){
            fumante = true;
        }
        else{
            fumante= false;
        }
        System.out.println("Digite a sua renda (use , para separar a parte decimal):");
        renda = entrada.nextDouble();
        System.out.println("");
        System.out.println("");
        
        System.out.println("Dados Cadastrados...");
        System.out.println("Nome Completo:"+ nome + " "+ sobreNome);
        System.out.println("idade: " +idade);
        System.out.println("Fumante: "+ fumante);
        System.out.println("Digite sua renda mensal: " + df.format(renda).toString());
        System.out.println("");
        System.out.println("Fim do programa!");
        
    }
    
}
