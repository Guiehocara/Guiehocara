/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juros;

/**
 *
 * @author mestr
 */
public class Juros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Montante;
        int tempo;
        float juros;
        int MontanteFinal;
        float Apenasojuros;
        Montante = 500;
        tempo = 3;
        juros = (float) 0.01;
        
        Apenasojuros = (float) Math.pow((1 + juros),tempo);
        MontanteFinal = (int) (Montante * Apenasojuros);
        System.out.println("Montante Final é: " + MontanteFinal);
        
    }
    
}
